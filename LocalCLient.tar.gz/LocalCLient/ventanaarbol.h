#ifndef VENTANAARBOL_H
#define VENTANAARBOL_H

#include <QWidget>

namespace Ui {
class ventanaArbol;
}

class ventanaArbol : public QWidget
{
    Q_OBJECT

public:
    explicit ventanaArbol(QWidget *parent = 0);
    ~ventanaArbol();

private:
    Ui::ventanaArbol *ui;
};

#endif // VENTANAARBOL_H
