#ifndef VENTANALISTA_H
#define VENTANALISTA_H

#include <QWidget>

namespace Ui {
class ventanaLista;
}

class ventanaLista : public QWidget
{
    Q_OBJECT

public:
    explicit ventanaLista(QWidget *parent = 0);
    ~ventanaLista();

private:
    Ui::ventanaLista *ui;
};

#endif // VENTANALISTA_H
