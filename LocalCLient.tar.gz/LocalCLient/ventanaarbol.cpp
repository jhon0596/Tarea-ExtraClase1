#include "ventanaarbol.h"
#include "ui_ventanaarbol.h"

ventanaArbol::ventanaArbol(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ventanaArbol)
{
    ui->setupUi(this);
}

ventanaArbol::~ventanaArbol()
{
    delete ui;
}
