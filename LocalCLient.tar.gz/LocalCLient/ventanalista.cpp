#include "ventanalista.h"
#include "ui_ventanalista.h"

ventanaLista::ventanaLista(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ventanaLista)
{
    ui->setupUi(this);
}

ventanaLista::~ventanaLista()
{
    delete ui;
}
