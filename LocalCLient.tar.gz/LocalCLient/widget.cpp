#include "widget.h"
#include "ui_widget.h"
#include <QTcpSocket>
#include <QTextStream>
#include "ventanalista.h"
Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    mSocket = new QTcpSocket(this);
    connect(mSocket,&QTcpSocket::readyRead,[&](){
        QTextStream T(mSocket);
    });
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_conectar_clicked()
{
    mSocket->connectToHost("localhost",8080);
    enviarMensaje("Hola");
}
void Widget::enviarMensaje(QString msj){
    if(mSocket){
        QTextStream T(mSocket);
        T<< msj;
        mSocket->flush();
    }
}

void Widget::leerMensaje( QTextStream T){
   QString mensaje = T.readLine();

}

void Widget::on_listaBoton_clicked()
{
    vl->show();
    enviarMensaje("lista");
    close();
}

void Widget::on_arbolBoton_clicked()
{
    va->show();
    enviarMensaje("arbol");
    close();
}
