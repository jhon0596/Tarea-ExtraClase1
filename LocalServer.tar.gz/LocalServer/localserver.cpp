#include "localserver.h"
#include <QTcpSocket>
#include<QTextStream>
#include"lista.h"
localServer::localServer(QObject *parent) : QTcpServer(parent)
{
    mSocket = nullptr;
    connect(this, &localServer::newConnection,[&](){
       mSocket = nextPendingConnection();
        QTextStream T(mSocket);
        leerMensaje(T.readAll());
    });

}
void localServer::enviarMensaje(QString msj){
    if(mSocket){
        QTextStream T(mSocket);
        T<< msj;
        mSocket->flush();
    }
}
void localServer::leerMensaje(QString T){
    *solicitud= T.prepend("/");
    *valor = T.append("/");
    if(*solicitud=="agregarInicio"){
        int nodeValor = valor->toInt(0);
        lista->addF(nodeValor);
    }

}
