#include "localserver.h"
#include <QTcpSocket>

localServer::localServer(QObject *parent) : QTcpServer(parent)
{
    mSocket = nullptr;
    connect(this, &localServer::newConnection,[&](){
       mSocket = nextPendingConnection();

    });

}
void localServer::enviarMensaje(QString msj){
    if(mSocket){
        QTextStream T(mSocket);
        T<< msj;
        mSocket->flush();
    }
}
void localServer::leerMensaje( QTextStream T){
    QString mensaje = T;
}

