#include "nodoab.h"

NodoAB::NodoAB()
{

}
NodoAB::NodoAB(int x) {
    clave = x;
    izq = der = nullptr;
}

bool NodoAB::esHoja() {
    return izq == nullptr && der == nullptr;
}

bool NodoAB::esInteriorUnHijo() {
    return (izq == nullptr && der != nullptr) || (izq != nullptr && der == nullptr);
}
