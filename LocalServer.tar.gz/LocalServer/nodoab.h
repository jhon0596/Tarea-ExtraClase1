#ifndef NODOAB_H
#define NODOAB_H


class NodoAB
{
public:
    NodoAB();
    NodoAB(int x);
    bool esHoja();
    bool esInteriorUnHijo();
    int clave;
    NodoAB *izq;
    NodoAB *der;
};

#endif // NODOAB_H
