#ifndef LOCALSERVER_H
#define LOCALSERVER_H

#include <QTcpServer>

class QTcpSocket;
class localServer : public QTcpServer


{
    Q_OBJECT
public:
    explicit localServer(QObject *parent = 0);
    void enviarMensaje(QString msj);
    void leerMensaje( QTextStream T);
private:
    QTcpSocket *mSocket;
signals:

public slots:
};

#endif // LOCALSERVER_H
