#ifndef LOCALSERVER_H
#define LOCALSERVER_H

#include <QTcpServer>
#include "lista.h"
class QTcpSocket;
class localServer : public QTcpServer


{
    Q_OBJECT
public:
    explicit localServer(QObject *parent = 0);
    void enviarMensaje(QString msj);
    void leerMensaje( QString T);
    Lista *lista;
    QString *valor;
    QString *solicitud;

private:
    QTcpSocket *mSocket;
signals:

public slots:
};

#endif // LOCALSERVER_H
