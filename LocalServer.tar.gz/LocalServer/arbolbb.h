#ifndef ARBOLBB_H
#define ARBOLBB_H
#include"nodoab.h"

class ArbolBB
{
public:
    ArbolBB();
    int valorMax(NodoAB *padre, NodoAB *nodo);
    bool estaVacio();
    void insertar(int clave);
    void buscarPI(NodoAB *nodo, int clave);
    void eliminar(int clave);
    void buscarClave(NodoAB *padre, NodoAB *nodo, int clave);
private:
    NodoAB *raiz = nullptr;
    NodoAB *actual = nullptr;
};

#endif // ARBOLBB_H
