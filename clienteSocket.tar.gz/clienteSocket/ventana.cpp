#include "ventana.h"
#include "ui_ventana.h"
#include <QTcpSocket>
#include <QTextStream>
#include<QMessageBox>

ventana::ventana(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ventana)
{
    ui->setupUi(this);
    mSocket = new QTcpSocket(this);
    connect(mSocket,&QTcpSocket::readyRead,[&](){
        QTextStream T(mSocket);
        ui->listWidget->addItem(T.readAll());
    });
}

ventana::~ventana()
{
    delete ui;
}

void ventana::on_bLista_clicked()
{
   if(ui->rbAgregarInicio->isChecked()){
       enviarMensaje("agregarInicio/"+ui->valorLista->text());
   }
   else if(ui->rbEliminarInicio->isChecked()){
       enviarMensaje("eliminarInicio");
   }
   else if(ui->rbEditarPosicion->isChecked()){
       enviarMensaje("EditarPosicion/"+ui->valorLista->text()+"/"+ui->posicionLista->text());
   }
   else if(ui->rbObtenerPosicion->isChecked()){
       enviarMensaje("obtenerPosicion/"+ui->posicionLista->text());
   }

}



void ventana::on_bConectar_clicked()
{
    mSocket->connectToHost("localhost",8080);
    enviarMensaje("Hola");
}

void ventana::enviarMensaje(QString msj){
    if(mSocket){
        QTextStream T(mSocket);
        T<< msj;
        mSocket->flush();
    }
}





void ventana::on_bArbol_clicked()
{
    if(ui->rbAgregarArbol->isChecked()){
        enviarMensaje("agregarArbol/"+ui->valorArbol->text());
    }
    else if(ui->rbEliminarArbol->isChecked()){
        enviarMensaje("eliminarArbol/"+ui->valorArbol->text());
    }
}

void ventana:: leerMensaje( QString T){
     QMessageBox::information(this,"Servidor",T);
}
