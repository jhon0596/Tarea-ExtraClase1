#ifndef VENTANA_H
#define VENTANA_H

#include <QWidget>
#include <QTextStream>
namespace Ui {
class ventana;
}
class QTcpSocket;
class ventana : public QWidget
{
    Q_OBJECT

public:
    explicit ventana(QWidget *parent = 0);
    void enviarMensaje(QString msj);
    void leerMensaje( QString T);
    ~ventana();

private slots:
    void on_bLista_clicked();

    void on_bConectar_clicked();

    void on_bArbol_clicked();

private:
    Ui::ventana *ui;
    QTcpSocket *mSocket;
};

#endif // VENTANA_H
